//
//  LocationViews.swift
//  MapApp
//
//  Created by Akshat  Bhansali on 23/04/23.
//

import SwiftUI

struct LocationViews: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LocationViews_Previews: PreviewProvider {
    static var previews: some View {
        LocationViews()
    }
}
